#!/bin/bash

#SBATCH --job-name=multithread
#SBATCH --partition=debug
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=16G
#SBATCH --time=02:00:00
#SBATCH --output=/home/s_tsion/HPC_assignment/logs/multithread_%j.out
#SBATCH --error=/home/s_tsion/HPC_assignment/logs/multithread_%j.err

echo "Multithreaded Bioinformatics Job"
echo "Job ID: $SLURM_JOB_ID"
echo "Hostname: $(hostname)"
echo "Allocated CPUs: $SLURM_CPUS_PER_TASK"

# Example bioinformatics command:
# minimap2 -t "$SLURM_CPUS_PER_TASK" reference.fa reads.fastq.gz > results/alignment.sam

echo "Multithreaded job script prepared."
