#!/bin/bash

#SBATCH --job-name=process_samples
#SBATCH --partition=debug
#SBATCH --array=1-10
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=512M
#SBATCH --time=00:05:00
#SBATCH --output=/home/s_tsion/HPC_assignment/logs/sample_%A_%a.out
#SBATCH --error=/home/s_tsion/HPC_assignment/logs/sample_%A_%a.err

cd /home/s_tsion/HPC_assignment

SAMPLE=$(sed -n "${SLURM_ARRAY_TASK_ID}p" samples.txt)

echo "Array job ID: $SLURM_ARRAY_JOB_ID"
echo "Task ID: $SLURM_ARRAY_TASK_ID"
echo "Processing sample: $SAMPLE"

echo "$SAMPLE processed successfully" > results/${SAMPLE}_result.txt

echo "Finished processing $SAMPLE"
