#!/bin/bash

#SBATCH --job-name=first_job
#SBATCH --partition=debug
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=2G
#SBATCH --time=00:10:00
#SBATCH --output=/home/s_tsion/HPC_assignment/logs/first_job_%j.out
#SBATCH --error=/home/s_tsion/HPC_assignment/logs/first_job_%j.err

echo "================================"
echo "First HPC SLURM Job"
echo "================================"

echo "Job ID: $SLURM_JOB_ID"
echo "Hostname: $(hostname)"
echo "Working directory: $(pwd)"
echo "Allocated CPUs: $SLURM_CPUS_PER_TASK"
echo "Start time: $(date)"

sleep 30

echo "End time: $(date)"
echo "Job completed successfully"
