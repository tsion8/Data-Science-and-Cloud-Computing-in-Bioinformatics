# RNA-Seq Transcriptome Reproduction: GSE52778

## Project Overview

This project reproduces key computational analyses from the study:

**Himes et al. (2014), "RNA-Seq Transcriptome Profiling Identifies CRISPLD2 as a Glucocorticoid Responsive Gene that Modulates Cytokine Function in Airway Smooth Muscle Cells."**

The study investigated gene-expression changes in primary human airway smooth muscle cells following dexamethasone (DEX) treatment.

The main objective of this reproduction was to compare the published differential-expression results with a modern DESeq2 analysis and determine whether the major biological findings, particularly the response of **CRISPLD2**, could be reproduced.

---

## Biological Experiment

* **Organism:** Human
* **Biological system:** Primary human airway smooth muscle cells
* **Cell lines/donors:** 4
* **Treatment:** Dexamethasone (DEX)
* **DEX concentration:** 1 μM
* **Treatment duration:** 18 hours
* **Comparison:** DEX-treated vs untreated
* **Sequencing platform:** Illumina HiSeq 2000
* **Read type:** 75-bp paired-end RNA-seq
* **Reference genome:** hg19

The original study used **TopHat 2.0.4, Cufflinks, and Cuffdiff** for transcriptome analysis.

---

## Dataset

**GEO accession:** GSE52778

The analysis in this project focuses on the eight samples corresponding to:

* 4 DEX-treated samples
* 4 untreated samples

The four cell lines were treated as paired biological samples in the DESeq2 analysis.

---

## Project Structure

```text
GSE52778_RNAseq_Reproduction/
│
├── data/
│   ├── raw/
│   └── processed/
│
├── notebooks/
│
├── results/
│   ├── figures/
│   └── tables/
│
└── README.md
```

### Data

The `data/processed/` directory contains the processed expression matrix and differential-expression results used in the analysis.
The original raw sequencing FASTQ files are not stored in this project repository because they are large sequencing files.

The data/raw/ directory is retained for project organization but is currently empty

### Notebooks

The `notebooks/` directory contains the analysis workflow and code used for data inspection, transformation, quality control, and statistical analysis.

### Results

The `results/figures/` directory contains generated plots, while `results/tables/` contains differential-expression and reproducibility tables.

---

## Analysis Workflow

The reproduction followed these major steps:

1. Understand the original study and experimental design.
2. Inspect the GSE52778 expression matrix.
3. Select the DEX and untreated samples.
4. Create sample metadata.
5. Convert the expression data from wide to long format.
6. Merge expression data with sample metadata.
7. Perform exploratory quality-control analysis.
8. Visualize expression distributions and sample correlations.
9. Perform principal component analysis (PCA).
10. Examine CRISPLD2 expression.
11. Reproduce the published Cuffdiff differential-expression results.
12. Perform differential-expression analysis using DESeq2.
13. Compare DESeq2 results with the original Cuffdiff results.
14. Examine important published genes.
15. Generate a paired CRISPLD2 expression plot.
16. Generate a DESeq2 volcano plot.
17. Assess biological and computational reproducibility.

---

## Quality Control

Quality-control analyses included:

* Expression distribution across samples
* Sample-to-sample correlation
* Principal component analysis (PCA)
* CRISPLD2 expression visualization

The PCA and sample-level analyses were used to evaluate whether the DEX-treated and untreated samples showed differences consistent with the experimental treatment.

---

## Differential Expression Analysis

### Original Study

The original study used **Cuffdiff** to compare DEX-treated and untreated samples.

Using the published Cuffdiff result file, the study identified:

**316 significantly differentially expressed genes at FDR < 0.05.**

### Reproduction

A DESeq2 analysis was performed using the paired experimental design:

```text
~ cell + dex
```

The cell term accounts for differences between the four cell lines, while the dex term estimates the treatment effect.

The DESeq2 analysis identified:

* **3,993 significant genes**
* **2,196 upregulated genes**
* **1,797 downregulated genes**
* Significance threshold: **FDR < 0.05**

Compared with the original 316 genes, the DESeq2 analysis identified **3,677 additional significant genes**.

---

## Important Genes

Seven genes highlighted in the original study were examined in the DESeq2 results:

* DUSP1
* KLF15
* PER1
* TSC22D3
* C7
* CCDC69
* CRISPLD2

All seven genes were significantly upregulated following DEX treatment in the DESeq2 analysis.

| Gene     | log2 Fold Change | Adjusted p-value |
| -------- | ---------------: | ---------------: |
| DUSP1    |             2.95 |    2.20 × 10⁻¹²⁶ |
| PER1     |             3.19 |     2.73 × 10⁻⁸¹ |
| KLF15    |             4.46 |     2.51 × 10⁻⁷⁷ |
| CCDC69   |             2.92 |     3.58 × 10⁻⁷⁰ |
| CRISPLD2 |             2.63 |     4.72 × 10⁻⁴⁶ |
| TSC22D3  |             3.19 |     3.47 × 10⁻¹⁹ |
| C7       |             3.20 |     1.87 × 10⁻¹² |

---

## CRISPLD2

CRISPLD2 was a major focus of the original study and was therefore examined separately.

In the DESeq2 analysis:

* **log2 fold change:** 2.63
* **adjusted p-value:** 4.72 × 10⁻⁴⁶

The paired expression analysis showed that CRISPLD2 expression increased from untreated to DEX-treated samples across the four cell lines.

This supports the original conclusion that **CRISPLD2 is responsive to glucocorticoid treatment**.

---

## Reproducibility Assessment

The exact number of significant genes reported by the original study was not reproduced.

| Feature                        | Original Study   | This Reproduction          |
| ------------------------------ | ---------------- | -------------------------- |
| Differential-expression method | Cuffdiff         | DESeq2                     |
| Design                         | DEX vs untreated | `~ cell + dex`             |
| Significance threshold         | FDR < 0.05       | FDR < 0.05                 |
| Significant genes              | 316              | 3,993                      |
| Important genes examined       | 7                | 7                          |
| Important genes reproduced     | —                | 7/7                        |
| CRISPLD2                       | Significant      | Significant, log2FC = 2.63 |

The difference in the number of significant genes may be related to differences in statistical methodology, normalization, filtering, annotation, and treatment of cell-line effects.

Therefore:

**Computational reproducibility: Partial**

**Biological reproducibility: Strong**

The major biological finding involving CRISPLD2 and the other important glucocorticoid-responsive genes was successfully reproduced, although the exact genome-wide differential-expression results differed from the original Cuffdiff analysis.

---

## Main Conclusion

This reproduction demonstrates that the major biological findings of the original Himes et al. study can be reproduced using a modern RNA-seq differential-expression workflow.

Although the DESeq2 analysis produced substantially more significant genes than the original Cuffdiff analysis, all seven selected genes from the published study were significantly upregulated in response to dexamethasone. In particular, CRISPLD2 showed a strong and statistically significant increase following treatment.

Overall, the analysis provides **strong biological reproducibility but only partial computational reproducibility**.

---

## Main Result Files

### Figures

```text
results/figures/
├── 01_expression_distribution.png
├── 02_sample_correlation.png
├── 03_PCA.png
├── 04_CRISPLD2_expression.png
├── 06_CRISPLD2_paired.png
└── 07_DESeq2_volcano.png
```

### Tables

```text
results/tables/
├── DESeq2_Dex_vs_Untreated.csv
├── DESeq2_top20_genes.csv
└── reproducibility_comparison.csv
```

---

## Software and Tools

The analysis used:

* Python
* pandas
* NumPy
* matplotlib
* scikit-learn
* R
* Bioconductor
* DESeq2
* airway

The `airway` Bioconductor dataset was used for the raw-count-based DESeq2 analysis because it contains the corresponding Himes et al. RNA-seq experiment with sample-level metadata and count data.

---

## References

Himes, B. E., Jiang, X., Wagner, P., Hu, R., Wang, Q., Klanderman, B., ... Silverman, E. K. (2014). RNA-Seq Transcriptome Profiling Identifies CRISPLD2 as a Glucocorticoid Responsive Gene that Modulates Cytokine Function in Airway Smooth Muscle Cells. *PLOS ONE*, 9(6), e99625.

**GEO accession:** GSE52778
