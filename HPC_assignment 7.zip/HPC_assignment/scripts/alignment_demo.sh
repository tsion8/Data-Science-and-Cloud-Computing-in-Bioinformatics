#!/bin/bash

#SBATCH --job-name=alignment_demo
#SBATCH --partition=debug
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=512M
#SBATCH --time=00:02:00
#SBATCH --output=/home/s_tsion/HPC_assignment/logs/alignment_%j.out
#SBATCH --error=/home/s_tsion/HPC_assignment/logs/alignment_%j.err

echo "Starting alignment"
sleep 15
echo "Alignment completed successfully"
