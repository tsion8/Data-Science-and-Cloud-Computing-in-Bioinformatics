# DESeq2 reproduction of Himes et al. 2014 (GSE52778): DEX vs untreated
# R 4.5.3, Bioconductor 3.22, DESeq2 1.50.2, airway 1.30.0
# Setup done once beforehand: BiocManager::install("DESeq2"); airway installed from a tar.gz.

setwd("C:/Users/MY-LENOVO/project")
library(SummarizedExperiment)
library(DESeq2)
library(airway)
data(airway)
print(as.data.frame(colData(airway))[, c("SampleName", "cell", "dex")])
print(dim(airway))
airway$dex <- relevel(airway$dex, ref = "untrt")
print(levels(airway$dex))
dds <- DESeqDataSet(airway, design = ~ cell + dex)
dds <- DESeq(dds)
res <- results(dds, contrast = c("dex", "trt", "untrt"), alpha = 0.05)
print(summary(res))
df <- as.data.frame(res)
df$ensembl <- rownames(df)
rd <- as.data.frame(rowData(airway))
df$symbol <- rd[["symbol"]][match(df$ensembl, rownames(rd))]
write.csv(df, "results/deseq2_results.csv", row.names = FALSE)
print(c(rows = nrow(df), tested = sum(!is.na(df$padj)), significant = sum(df$padj < 0.05, na.rm = TRUE)))
print(df[which(df$symbol == "CRISPLD2"), ])
dds2 <- DESeqDataSet(airway, design = ~ dex)
dds2 <- DESeq(dds2)
res2 <- results(dds2, contrast = c("dex", "trt", "untrt"), alpha = 0.05)
print(sum(res2$padj < 0.05, na.rm = TRUE))
sessionInfo()
