#!/bin/bash

#SBATCH --job-name=variant_demo
#SBATCH --partition=debug
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=512M
#SBATCH --time=00:02:00
#SBATCH --output=/home/s_tsion/HPC_assignment/logs/variant_%j.out
#SBATCH --error=/home/s_tsion/HPC_assignment/logs/variant_%j.err

echo "Starting variant calling"
echo "Variant calling completed successfully"
